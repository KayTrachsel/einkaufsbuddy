<script setup>
import { ref, onMounted } from 'vue';
import { fetchItems, fetchStores } from '../api/request.js';
import { RouterLink } from 'vue-router';

const items = ref([]);
const loading = ref(true);
const stores = ref([]);

onMounted(async () => {
    load();
});

async function load() {
    loading.value = true;
    try {
        const data = await fetchItems();
        items.value = data.records;
        console.log('Stream geladen', items.value);
        const storeData = await fetchStores();
        stores.value = storeData.records;
        console.log('Stores geladen', stores.value);
    } catch (error) {
        console.error(error);
    } finally {
        loading.value = false;
    }
}

async function getStoreName(storeId) {
  for (const element of stores.value) {
    if (element.id == storeId) {
      return element.fields.Name;
    }
  }
}
</script>

<template>
  <div class="items-container">
    <RouterLink to="/" class="home-button">
      Home
    </RouterLink>

    <h1>Items</h1>
    <div v-if="loading">Loading...</div>
    <table v-else class="styled-table">
      <thead>
        <tr>
          <th>Item</th>
          <th>Price</th>
          <th>Stores</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.id">
          <td>{{ item.fields.Name }}</td>
          <td>{{ item.fields.Price }} CHF</td>
          <td>{{ item.fields.StoreName[0] }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>